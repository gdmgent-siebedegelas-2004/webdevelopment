<a href="#"><i class="fal fa-lightbulb"></i> <span><?= $btn->name ?></span></a>

<!-- 
<a href="#"><i class="fal fa-lightbulb"></i> <span>Keuken aanrecht</span></a>
<a href="#" class="active"><i class="fal fa-lightbulb"></i> <span>Salon</span></a>
<a href="#"><i class="fal fa-lightbulb"></i> <span>Eetplaats</span></a>
<a href="#"><i class="fal fa-lightbulb"></i> <span>Keukentafel</span></a>
<a href="#" class="active"><i class="fal fa-lightbulb"></i> <span>Sfeer</span></a> -->