<a href="#<?= $roomlist->name ?>"><i class="fal fa-<?= $roomlist->icon ?>"></i> <span><?= $roomlist->name ?></span></a>


